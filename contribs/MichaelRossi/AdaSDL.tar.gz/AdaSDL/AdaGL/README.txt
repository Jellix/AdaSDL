This is the AdaGL library by Antonio M. F. Vargas.
http://www.adapower.net/~avargas/

I just changed the makefile to turn these into static and shared libs.

For install info please see

INSTALL.txt

Please note: To make the AdaSDL GL examples,
you will also need this library.

These bindings do not conflict with the AdaOpenGL bindings at 
http://www.cs.chalmers.se/~bond/OPENGL/ADA/
or
http://www.qlippoth.com/AdaOpenGL.tar.gz

This OpenGL lib is linked as:    -lAdaOpenGL
while this library is linked as: -lAdaGL

Tested on Mandrake 8.0 and 8.1.

--
file13@qlippoth.zzn.com
