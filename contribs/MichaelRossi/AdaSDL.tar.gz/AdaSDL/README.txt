This is a more developer friendly verion of Vargas'
his Ada OpenGL and SDL bindings version AdaSDL_20010504.tar.gz.

For more info see:

https://sourceforge.net/projects/adasdl/
or
http://www.adapower.net/~avargas/

At this time only the Linux Makefile's work.
You'll still have to do Windows manually.


*************** IMPORTANT *****************
Please AdaGL first, then AdaSDL or the
examples will not compile correctly.
*******************************************

The other directory contains the other packages that
came with AdaSDL_20010504.tar.gz unmodified.

That's all!

Michael Rossi
file13@qlippoth.zzn.com
http://www.qlippoth.com/
Wed Oct 17 16:02:30 CDT 2001
