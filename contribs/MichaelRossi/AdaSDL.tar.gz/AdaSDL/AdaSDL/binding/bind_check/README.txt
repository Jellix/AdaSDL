
The purpose of this directory is to verify the correct sizes of the structures/records  of the binding
you must recompile and run "verify_ada_sizes" every time you suspect some incompatibilities.

TO DO:
   To put in "verify_ada_sizes" all the binding records


