#include <SDL.h>
#include <stdio.h>


void main (void)
{
   printf ("SDL_PEEKEVENT = %d\n", SDL_PEEKEVENT);
   printf ("SDL_QUIT = %d\n", SDL_QUIT);
   printf ("SDL_QUITMASK = %d\n", SDL_QUITMASK);
};
