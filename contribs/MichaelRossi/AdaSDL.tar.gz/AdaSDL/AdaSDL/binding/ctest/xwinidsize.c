#include <X.h>


int main (void)
{
  printf (" X Window ID size is %d\n", sizeof(Window));
   return 0;
}
