This is the AdaSDL library by Antonio M. F. Vargas.
http://www.adapower.net/~avargas/

I just changed the makefile to turn these into static and shared libs.

For install info please see

INSTALL.txt

Note: to compile to GL examples, you must first install
Vargas' AdaGL.

Tested on Mandrake 8.0 and 8.1.

--
file13@qlippoth.zzn.com