
--  ======================================
This directory is under construction.
--  ======================================

In this directory you will find files for
a future tutorial. Not important at the moment.

I've used PovRay to design the image files.
