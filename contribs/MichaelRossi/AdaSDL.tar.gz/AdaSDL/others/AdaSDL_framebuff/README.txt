Ada Low Graphics Layer
    This is an adaptation layer between the SDL binding and normal Ada programming.
