
SDL_mixer binding

This software depends on AdaSDL binding.
Get it from http://www.adapower.net/~avargas.

In windows do:
   make conf2w32
   make

In linux do:
   make conf2x11
   make

The AdaSDL binding is supposed to be at "../AdaSDL/binding" 
